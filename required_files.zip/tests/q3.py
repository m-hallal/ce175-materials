OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q3)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(gravel_or_sand(70, 45).upper()) == 'dfcf28d0734569a6a693bc8194de62bf'\n"
                                               ">>> assert get_hash(gravel_or_sand(80, 70).upper()) == 'dfcf28d0734569a6a693bc8194de62bf'\n"
                                               ">>> assert get_hash(gravel_or_sand(80, 60.78).upper()) == 'dfcf28d0734569a6a693bc8194de62bf'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(gravel_or_sand(70, 35).upper()) == '5dbc98dcc983a70728bd082d1a47546e'\n"
                                               ">>> assert get_hash(gravel_or_sand(80, 50).upper()) == '5dbc98dcc983a70728bd082d1a47546e'\n"
                                               ">>> assert get_hash(gravel_or_sand(80, 59.18).upper()) == '5dbc98dcc983a70728bd082d1a47546e'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

OK_FORMAT = True

test = {   'name': 'q8',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q8)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(classify_fine(55, 25).upper()) == '1ee0bf89c5d1032317d13a2e022793c8'\n"
                                               ">>> assert get_hash(classify_fine(75, 25).upper()) == '1ee0bf89c5d1032317d13a2e022793c8'\n"
                                               ">>> assert get_hash(classify_fine(60, 30.7).upper()) == '1ee0bf89c5d1032317d13a2e022793c8'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(classify_fine(30, 20).upper()) == '5bc574a47246f122016869b32a6aa6f0'\n"
                                               ">>> assert get_hash(classify_fine(20, 10).upper()) == '5bc574a47246f122016869b32a6aa6f0'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(classify_fine(55, 45).upper()) == '002f27e5064e874ecf4f5def17d1b797'\n"
                                               ">>> assert get_hash(classify_fine(75, 45).upper()) == '002f27e5064e874ecf4f5def17d1b797'\n"
                                               ">>> assert get_hash(classify_fine(60, 30.9).upper()) == '002f27e5064e874ecf4f5def17d1b797'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(classify_fine(30, 25).upper()) == 'd01fd9b01e9dde8bd3dc247afbfb7218'\n"
                                               ">>> assert get_hash(classify_fine(10, 7).upper()) == 'd01fd9b01e9dde8bd3dc247afbfb7218'\n"
                                               ">>> assert get_hash(classify_fine(20, 17).upper()) == 'd01fd9b01e9dde8bd3dc247afbfb7218'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(classify_fine(10, 5).upper()) == '6ee58e48c2cb2ff01807ccca4667e070'\n"
                                               ">>> assert get_hash(classify_fine(20, 14).upper()) == '6ee58e48c2cb2ff01807ccca4667e070'\n"
                                               ">>> assert get_hash(classify_fine(26, 20).upper()) == '6ee58e48c2cb2ff01807ccca4667e070'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

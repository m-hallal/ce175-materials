OK_FORMAT = True

test = {   'name': 'q5',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(q5)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(gradation(70, 45, 0.15, 0.13, 0.1).upper()) == '44c29edb103a2872f519ad0c9a0fdaaa'\n"
                                               ">>> assert get_hash(gradation(70, 45, 0.15, 0.11, 0.1).upper()) == '44c29edb103a2872f519ad0c9a0fdaaa'\n"
                                               ">>> assert get_hash(gradation(70, 45, 0.15, 0.14, 0.005).upper()) == '44c29edb103a2872f519ad0c9a0fdaaa'\n"
                                               ">>> assert get_hash(gradation(50, 25, 0.5, 0.251, 0.126).upper()) == '44c29edb103a2872f519ad0c9a0fdaaa'\n"
                                               ">>> assert get_hash(gradation(50, 25, 0.5, 0.248, 0.124).upper()) == '44c29edb103a2872f519ad0c9a0fdaaa'\n"
                                               ">>> assert get_hash(gradation(50, 25, 0.5, 0.432, 0.124).upper()) == '44c29edb103a2872f519ad0c9a0fdaaa'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(gradation(70, 45, 0.45, 0.3, 0.1).upper()) == '61e9c06ea9a85a5088a499df6458d276'\n"
                                               ">>> assert get_hash(gradation(50, 25, 0.65, 0.3, 0.1).upper()) == '61e9c06ea9a85a5088a499df6458d276'\n"
                                               ">>> assert get_hash(gradation(50, 25, 0.5, 0.251, 0.124).upper()) == '61e9c06ea9a85a5088a499df6458d276'\n"
                                               ">>> assert get_hash(gradation(50, 25, 0.5, 0.431, 0.124).upper()) == '61e9c06ea9a85a5088a499df6458d276'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(gradation(70, 35, 0.15, 0.13, 0.1).upper()) == '44c29edb103a2872f519ad0c9a0fdaaa'\n"
                                               ">>> assert get_hash(gradation(70, 35, 0.45, 0.3, 0.1).upper()) == '44c29edb103a2872f519ad0c9a0fdaaa'\n"
                                               ">>> assert get_hash(gradation(70, 35, 0.15, 0.11, 0.1).upper()) == '44c29edb103a2872f519ad0c9a0fdaaa'\n"
                                               ">>> assert get_hash(gradation(70, 35, 0.15, 0.14, 0.005).upper()) == '44c29edb103a2872f519ad0c9a0fdaaa'\n"
                                               ">>> assert get_hash(gradation(70, 35, 0.5, 0.204, 0.0834).upper()) == '44c29edb103a2872f519ad0c9a0fdaaa'\n"
                                               ">>> assert get_hash(gradation(70, 35, 0.5, 0.203, 0.0833).upper()) == '44c29edb103a2872f519ad0c9a0fdaaa'\n"
                                               ">>> assert get_hash(gradation(70, 35, 0.5, 0.353, 0.083).upper()) == '44c29edb103a2872f519ad0c9a0fdaaa'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(gradation(70, 35, 0.65, 0.3, 0.1).upper()) == '61e9c06ea9a85a5088a499df6458d276'\n"
                                               ">>> assert get_hash(gradation(70, 35, 0.5, 0.204, 0.083).upper()) == '61e9c06ea9a85a5088a499df6458d276'\n"
                                               ">>> assert get_hash(gradation(70, 35, 0.5, 0.352, 0.083).upper()) == '61e9c06ea9a85a5088a499df6458d276'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

OK_FORMAT = True

test = {   'name': 'q4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> assert get_hash(type(Cu)) != '14e736438b115821cbb9b7ac0ba79034'\n>>> assert get_hash(type(Cc)) != '14e736438b115821cbb9b7ac0ba79034'\n",
                                       'failure_message': 'Make sure to test your function!',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(round(coefficients(0.15, 0.13, 0.1)[0], 3)) == '6008647277c4454cecd97d33c069f0ca'\n"
                                               ">>> assert get_hash(round(coefficients(2, 1.1, 0.3)[0], 3)) == 'c3e5bc1a469d73f843b6bcb150cd868e'\n"
                                               ">>> assert get_hash(round(coefficients(1.1, 0.075, 0.005)[0], 3)) == '2d22f62e9e38119403851fbf17cb26b1'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> assert get_hash(round(coefficients(0.15, 0.13, 0.1)[1], 3)) == 'e1efa1216f20c79a077a45c36dd0bd32'\n"
                                               ">>> assert get_hash(round(coefficients(2, 1.1, 0.3)[1], 3)) == '31ca5cbbaff2e53df4c500d50e94f943'\n"
                                               ">>> assert get_hash(round(coefficients(1.1, 0.075, 0.005)[1], 3)) == '4e421203259d2f9b4cad729e5ee3bfd1'\n",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
